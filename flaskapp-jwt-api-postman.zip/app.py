import os
import sys
import uuid

from werkzeug.security import generate_password_hash, check_password_hash

relative = "../"
sys.path.insert(1, str(os.path.abspath(relative)))
import datetime

import configparser
from functools import wraps

config = configparser.ConfigParser()
import jwt

import pytz
import re
import json

from flask import Flask, render_template, request, redirect ,jsonify, make_response
from flask_sqlalchemy import SQLAlchemy

import configparser
from helper import setup_logger


secret_key = b'gslabflaskAssign@123'

config = configparser.ConfigParser()
config.read('config.ini')

app = Flask(__name__, template_folder=config.get('constants', 'template_folder'))
app.config['SQLALCHEMY_DATABASE_URI'] = config.get('constants', 'db_url')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SECRET_KEY'] =config.get('credentials', 'secret_key')

db = SQLAlchemy(app)

email_regex = config.get('constants', 'email_regex')


class Employees(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    first_name = db.Column(db.String(200), nullable=False)
    last_name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), nullable=False, unique=True)
    datecreated = db.Column(db.DateTime())

    def __repr__(self):
        return '<emp %r>' % self.id


class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.Integer)
    name = db.Column(db.String(50))
    password = db.Column(db.String(50))
    admin = db.Column(db.Boolean)

    def __repr__(self):
        return '<user %r>' % self.id



def token_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):
        token = None
        if 'x-access-tokens' in request.headers:
            token = request.headers['x-access-tokens']

        if not token:
            return jsonify({'message': 'a valid token is missing'})
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = Users.query.filter_by(public_id=data['public_id']).first()
        except:
            return jsonify({'message': 'token is invalid'})

        return f(current_user, *args, **kwargs)
    return decorator


@app.route('/register', methods=['POST'])
def signup_user():
    data = request.get_json()
    hashed_password = generate_password_hash(data['password'], method='sha256')

    new_user = Users(public_id=str(uuid.uuid4()), name=data['name'], password=hashed_password, admin=False)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User successfully Registered in the Portal.'})


@app.route('/login', methods=['POST'])
def login_user():
    auth = request.authorization
    if not auth or not auth.username or not auth.password:
        return make_response('could not verify', 401, {'Authentication': 'login required"'})

    user = Users.query.filter_by(name=auth.username).first()
    if check_password_hash(user.password, auth.password):
        token = jwt.encode(
            {'public_id': user.public_id, 'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=45)},
            app.config['SECRET_KEY'], "HS256")

        return jsonify({'token': token})

    return make_response('could not verify', 401, {'Authentication': '"login required"'})


@app.route('/', methods=['GET'])
@token_required
def index(usr):
    return redirect("/employee", code=302)


@app.route('/users', methods=['GET'])
def get_all_users():
    users = Users.query.all()
    result = []
    for user in users:
        user_data = {}
        user_data['public_id'] = user.public_id
        user_data['name'] = user.name
        user_data['password'] = user.password
        user_data['admin'] = user.admin

        result.append(user_data)
    return jsonify({'users': result})


@app.route('/employee', methods=['GET'])
@token_required
def home_page(usr):
    if request.method == 'GET':
        emps = Employees.query.all()
        cols = ['id', 'first_name', 'last_name', 'email']
        result = [{col: getattr(d, col) for col in cols} for d in emps]
        return (json.dumps(result))

@app.route('/employee/add_employee', methods=['POST', 'GET'])
@token_required
def add_employee_page(usr):
    if request.method == 'GET':
        return render_template("addpage.html")
    elif request.method == 'POST':
        request_data = request.get_json()
        first_name_req = request_data['firstname']
        last_name_req = request_data['lastname']
        email_req = request_data['email']

        if re.fullmatch(email_regex, email_req):
            tz = pytz.timezone('Asia/Kolkata')
            a_datecreated = datetime.datetime.now().astimezone(tz)
            new_emp = Employees(first_name=first_name_req, last_name=last_name_req, email=email_req,
                                datecreated=a_datecreated)
            try:
                db.session.add(new_emp)
                db.session.flush()
                logger.info(f'{email_req} user added')
                return {
                    "message": "Employee Sucessfully Added.",
                }
            except Exception as exception_msg:
                db.session.rollback()
                resp = duplicate_email_exception(str(exception_msg))
                return resp
            finally:
                db.session.commit()
                db.engine.dispose()


@app.route('/employee/delete_employee/<id>', methods=['GET'])
@token_required
def delete_employee_page(usr,id):
    emp_to_delete = Employees.query.get_or_404(id)
    try:
        db.session.delete(emp_to_delete)
        db.session.flush()
        logger.info(f'Deleted employee :" +{str(emp_to_delete)}')
        return {
            "message": "Employee Sucessfully Deleted.",
        }
    except Exception as e:
        db.session.rollback()
        logger.info(f'Exception : "there was an issue deleting employee :"{str(e)}')
        return "there was a problem"
    finally:
        db.session.commit()
        db.engine.dispose()


@app.route('/employee/edit_employee/<int:id>', methods=['POST'])
@token_required
def edit_employee_page(usr,id: int):
    if request.method == 'POST':
        try:
            request_data = request.get_json()
            first_name_req = request_data['firstname']
            last_name_req = request_data['lastname']
            email_req = request_data['email']

            if re.fullmatch(email_regex, email_req):
                tz = pytz.timezone('Asia/Kolkata')
                Employees.query.filter_by(id=id).update(
                    dict(first_name=first_name_req, last_name=last_name_req, email=email_req))
                try:
                    db.session.flush()
                    logger.info(f'Edited employee :" {str(email_req)}')
                    return {
                        "message": "Employee Sucessfully Edited.",
                    }
                except Exception as exception_msg:
                    db.session.rollback()
                    resp = duplicate_email_exception(str(exception_msg))
                    return resp
                finally:
                    db.session.commit()
                    db.engine.dispose()
            else:
                return {
                    "EmailValidationError": "Please Provide a Valid Email Address",
                }
        except Exception as e:
            return {
                "Error": "Issue Processing Editing",
            }

def duplicate_email_exception(exception: str):
    try:
        if 'sqlite3.IntegrityError' in str(exception):
            logger.info(f'Exception : "Duplicate issue editing employee :"{str(exception)}')
            return {
                "DuplicateEmailError": "Employee Already Exist",
            }
        else:
            logger.info(f'Exception : "Some issue editing employee :"{str(exception)}')
            return ' There was an Error while editing'
    except Exception as e:
        logger.info(f'Exception : "Some issue editing employee :"{str(e)}')


if __name__ == '__main__':
    try:
        logger = setup_logger()
        app.run(host='127.0.0.1', port='3000', debug=False)
        logger.info('Flask App Started')
    except Exception as e:
        logger.info('Issue starting the Flask Application')
